import mysql from "mysql2/promise";

let pool = null;
export function getPool() {
  if (pool) return pool;
  const { DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD } = process.env;
  if (!DB_HOST || !DB_NAME || !DB_USER) return null;
  pool = mysql.createPool({ host: DB_HOST, port: Number(DB_PORT || 3306), database: DB_NAME, user: DB_USER, password: DB_PASSWORD || "", waitForConnections: true, connectionLimit: Number(process.env.DB_CONNECTION_LIMIT || 10), decimalNumbers: true, charset: "utf8mb4" });
  return pool;
}
export async function withTransaction(callback) {
  const activePool = getPool();
  if (!activePool) throw new Error("MYSQL_NOT_CONFIGURED");
  const connection = await activePool.getConnection();
  try { await connection.beginTransaction(); const result = await callback(connection); await connection.commit(); return result; }
  catch (error) { await connection.rollback(); throw error; }
  finally { connection.release(); }
}
