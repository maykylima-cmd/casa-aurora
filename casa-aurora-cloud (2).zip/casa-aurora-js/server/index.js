import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import { randomInt } from "crypto";
import { getPool, withTransaction } from "./db.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const server = createServer(app);
const publicPath = path.resolve(__dirname, "..", "public");
const serviceFeeRate = 0.1;
app.use(express.json({ limit: "100kb" }));
app.get("/api/health", async (_req, res) => { const pool = getPool(); if (!pool) return res.status(503).json({ ok: false, database: "not_configured", message: "Configure DB_HOST, DB_NAME e DB_USER no ambiente do serviço." }); try { await pool.query("SELECT 1"); return res.json({ ok: true, database: "connected" }); } catch (error) { console.error("MySQL health check failed", error); return res.status(503).json({ ok: false, database: "unavailable", message: "O MySQL não está acessível a partir do servidor." }); } });
app.post("/api/orders", async (req, res) => {
  const { customerName, tableNumber, paymentMethod, serviceFeeEnabled = true, items } = req.body ?? {};
  const table = Number(tableNumber); const payments = new Set(["card", "pix", "cash"]);
  if (typeof customerName !== "string" || customerName.trim().length < 2) return res.status(400).json({ error: "Informe um nome válido." });
  if (!Number.isInteger(table) || table < 1 || table > 50) return res.status(400).json({ error: "A mesa deve estar entre 1 e 50." });
  if (!payments.has(paymentMethod)) return res.status(400).json({ error: "Forma de pagamento inválida." });
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "O pedido precisa ter ao menos um item." });
  const normalized = items.map((item) => ({ productId: String(item?.productId || ""), quantity: Number(item?.quantity) })).filter((item) => item.productId && Number.isInteger(item.quantity) && item.quantity > 0 && item.quantity <= 99);
  if (normalized.length !== items.length) return res.status(400).json({ error: "Itens ou quantidades inválidos." });
  try {
    const order = await withTransaction(async (connection) => {
      const ids = normalized.map((item) => item.productId); const placeholders = ids.map(() => "?").join(",");
      const [rows] = await connection.query(`SELECT id, name, price FROM products WHERE active = 1 AND id IN (${placeholders})`, ids);
      const products = new Map(rows.map((product) => [product.id, product]));
      if (products.size !== new Set(ids).size) throw new Error("PRODUCT_NOT_FOUND");
      const priced = normalized.map((item) => { const product = products.get(item.productId); return { ...item, name: product.name, unitPrice: Number(product.price), itemTotal: Number(product.price) * item.quantity }; });
      const subtotal = priced.reduce((sum, item) => sum + item.itemTotal, 0); const serviceFee = serviceFeeEnabled ? subtotal * serviceFeeRate : 0; const total = subtotal + serviceFee; const reference = `CA-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomInt(1000, 10000)}`;
      const [result] = await connection.execute("INSERT INTO orders (reference, customer_name, table_number, service_fee_enabled, service_fee_rate, subtotal, service_fee, total, status, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'received', ?)", [reference, customerName.trim(), String(table), Boolean(serviceFeeEnabled), serviceFeeRate, subtotal, serviceFee, total, paymentMethod]);
      for (const item of priced) await connection.execute("INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity, item_total) VALUES (?, ?, ?, ?, ?, ?)", [result.insertId, item.productId, item.name, item.unitPrice, item.quantity, item.itemTotal]);
      return { id: result.insertId, reference, customerName: customerName.trim(), tableNumber: table, paymentMethod, items: priced, subtotal, serviceFee, total };
    });
    return res.status(201).json({ order });
  } catch (error) { if (error instanceof Error && error.message === "MYSQL_NOT_CONFIGURED") return res.status(503).json({ error: "Banco de dados não configurado no servidor.", code: "MYSQL_NOT_CONFIGURED" }); if (error instanceof Error && error.message === "PRODUCT_NOT_FOUND") return res.status(400).json({ error: "Um ou mais produtos não estão disponíveis.", code: "PRODUCT_NOT_FOUND" }); console.error("Order creation failed", error); return res.status(500).json({ error: "Não foi possível registrar o pedido.", code: "ORDER_PERSISTENCE_FAILED" }); }
});
app.use(express.static(publicPath));
app.use("/api", (_req, res) => res.status(404).json({ error: "Endpoint não encontrado." }));
app.get("*", (_req, res) => res.sendFile(path.join(publicPath, "index.html")));
server.listen(Number(process.env.PORT || 3000), () => console.log("Casa Aurora JS running"));
