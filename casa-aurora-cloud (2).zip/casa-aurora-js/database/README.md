# Banco de dados e API

A API Express usa `mysql2/promise` e lê a conexão pelas variáveis de ambiente `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_CONNECTION_LIMIT` e `PORT`.

## Inicialização do MySQL

Execute primeiro `schema.sql` em um servidor MySQL 8+ e depois `seed.sql`. O schema cria as tabelas `categories`, `products`, `orders` e `order_items`, além dos índices, chaves estrangeiras e triggers de total dos itens.

O seed atual cria as cinco categorias. Para que a API aceite pedidos, os 150 produtos do catálogo também precisam existir na tabela `products`, usando os mesmos IDs de `client/src/lib/menuData.ts`.

## API

`GET /api/health` verifica se as variáveis estão configuradas e se o MySQL responde.

`POST /api/orders` grava um pedido transacionalmente. O corpo esperado é:

```json
{
  "customerName": "Marina",
  "tableNumber": 12,
  "paymentMethod": "pix",
  "serviceFeeEnabled": true,
  "items": [{ "productId": "entradas-1", "quantity": 2 }]
}
```

O servidor consulta os preços no banco, recalcula subtotal, taxa e total, gera uma referência no formato `CA-YYYYMMDD-XXXX` e grava o pedido e seus itens. Não confia em preços enviados pelo navegador.

Sem as variáveis MySQL, o servidor continua servindo o frontend, mas `POST /api/orders` responde `503` informando que o banco não está configurado. Nenhum pedido é considerado persistido nesse estado.

## Versão sem React

A versão independente feita somente com HTML, CSS e JavaScript está em `vanilla/` e fica disponível em `/vanilla/` quando o servidor Express está rodando. O comando `pnpm start:vanilla` inicia o servidor JavaScript puro; é necessário executar o build antes para disponibilizar os arquivos estáticos React no fallback, embora a rota `/vanilla/` seja servida diretamente da pasta `vanilla/`.
