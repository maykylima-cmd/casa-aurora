import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import sqlite3 from "sqlite3";

const SQLite = sqlite3.verbose();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataDirectory = path.resolve(__dirname, "../database");
const databasePath = path.join(dataDirectory, "casa-aurora.db");
let databasePromise;

function loadCatalog() {
  const source = fs.readFileSync(path.resolve(__dirname, "../public/menu-data.js"), "utf8");
  const context = { window: {} };
  vm.runInNewContext(source, context);
  return context.window.CASA_AURORA_DATA;
}
function openDatabase() { return new Promise((resolve, reject) => { const db = new SQLite.Database(databasePath, (error) => error ? reject(error) : resolve(db)); }); }
function exec(db, sql) { return new Promise((resolve, reject) => db.exec(sql, (error) => error ? reject(error) : resolve())); }
function run(db, sql, params = []) { return new Promise((resolve, reject) => db.run(sql, params, function (error) { error ? reject(error) : resolve({ lastID: this.lastID, changes: this.changes }); })); }
function all(db, sql, params = []) { return new Promise((resolve, reject) => db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows))); }
function get(db, sql, params = []) { return new Promise((resolve, reject) => db.get(sql, params, (error, row) => error ? reject(error) : resolve(row))); }

async function initialize() {
  fs.mkdirSync(dataDirectory, { recursive: true });
  const db = await openDatabase();
  await exec(db, `PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS categories (id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, description TEXT, sort_order INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, category_id TEXT NOT NULL, name TEXT NOT NULL, description TEXT NOT NULL, price REAL NOT NULL CHECK(price >= 0), tag TEXT, featured INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(category_id) REFERENCES categories(id));
    CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, reference TEXT NOT NULL UNIQUE, customer_name TEXT NOT NULL, table_number TEXT NOT NULL, service_fee_enabled INTEGER NOT NULL DEFAULT 1, service_fee_rate REAL NOT NULL DEFAULT 0.1, subtotal REAL NOT NULL DEFAULT 0, service_fee REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0, payment_method TEXT NOT NULL DEFAULT 'card', status TEXT NOT NULL DEFAULT 'received', notes TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id TEXT NOT NULL, product_name TEXT NOT NULL, unit_price REAL NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0), item_total REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
    CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at);
    CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);`);
  const catalog = loadCatalog();
  await exec(db, "BEGIN TRANSACTION");
  try {
    for (const [index, category] of catalog.categories.entries()) await run(db, "INSERT INTO categories (id, name, description, sort_order) VALUES (?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, description=excluded.description, sort_order=excluded.sort_order", [category.id, category.label, category.description, index + 1]);
    for (const product of catalog.products) await run(db, "INSERT INTO products (id, category_id, name, description, price, tag, featured, active) VALUES (?, ?, ?, ?, ?, ?, ?, 1) ON CONFLICT(id) DO UPDATE SET category_id=excluded.category_id, name=excluded.name, description=excluded.description, price=excluded.price, tag=excluded.tag, featured=excluded.featured, active=1", [product.id, product.category, product.name, product.description, product.price, product.tag || null, product.featured ? 1 : 0]);
    await exec(db, "COMMIT");
  } catch (error) { await exec(db, "ROLLBACK"); throw error; }
  return { db, run, all, get };
}
export function getDatabase() { if (!databasePromise) databasePromise = initialize(); return databasePromise; }
export async function withTransaction(callback) { const database = await getDatabase(); await exec(database.db, "BEGIN TRANSACTION"); try { const result = await callback(database); await exec(database.db, "COMMIT"); return result; } catch (error) { await exec(database.db, "ROLLBACK"); throw error; } }
