# Casa Aurora — versão somente JavaScript

Esta distribuição não contém React, TypeScript, TSX, Vite ou arquivos `.ts`/`.tsx`.

## Conteúdo

- `public/index.html`: estrutura da interface
- `public/style.css`: estilos responsivos
- `public/app.js`: catálogo, busca, carrinho e checkout
- `public/menu-data.js`: 150 produtos
- `server/index.js`: API Express em JavaScript
- `server/db.js`: conexão MySQL em JavaScript
- `database/schema.sql`: tabelas MySQL
- `database/seed.sql`: categorias e 150 produtos

## Uso

1. Instale Node.js 18+ e MySQL 8+.
2. Execute `npm install`.
3. Execute `database/schema.sql` e `database/seed.sql` no MySQL.
4. Configure `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` e `PORT`.
5. Rode `npm start`.
6. Abra `http://localhost:3000`.

Sem as variáveis do MySQL, a interface abre, mas os pedidos retornam erro 503 e não são persistidos.
