# Casa Aurora — versão somente JavaScript

Esta distribuição não contém React, TypeScript, TSX, Vite ou arquivos `.ts`/`.tsx`.

## Conteúdo

- `public/index.html`: estrutura da interface
- `public/style.css`: estilos responsivos
- `public/app.js`: catálogo, busca, carrinho e checkout
- `public/menu-data.js`: 150 produtos
- `server/index.js`: API Express em JavaScript
- `server/db.js`: conexão MySQL em JavaScript
- `database/schema.sql`: tabelas MySQL
- `database/seed.sql`: categorias e 150 produtos

## Uso

1. Instale Node.js 18+ e MySQL 8+.
2. Execute `npm install`.
3. Execute `database/schema.sql` e `database/seed.sql` no MySQL.
4. Configure `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` e `PORT`.
5. Rode `npm start`.
6. Abra `http://localhost:3000`.

Sem as variáveis do MySQL, a interface abre, mas os pedidos retornam erro 503 e não são persistidos.

## Implantação portátil na nuvem

A forma mais portátil é usar Docker Compose. Copie `.env.example` para `.env`, troque `DB_PASSWORD` e `MYSQL_ROOT_PASSWORD` por senhas fortes e execute:

```bash
cp .env.example .env
docker compose up -d --build
```

A aplicação ficará em `http://SEU_HOST:3000`. O serviço MySQL usa o volume nomeado `mysql_data`, executa `database/schema.sql` e `database/seed.sql` automaticamente na primeira inicialização e mantém os dados entre reinícios. Não remova o volume se quiser preservar pedidos e produtos.

Para verificar a conexão:

```bash
curl http://localhost:3000/api/health
docker compose logs -f app
```

Para levar a aplicação a um provedor, envie este diretório para um registro Git ou para um serviço que aceite Docker. Configure `PORT` conforme o provedor e mantenha `DB_HOST`, `DB_NAME`, `DB_USER` e `DB_PASSWORD` como variáveis secretas. Em provedores que oferecem MySQL separado, use o host privado do banco e execute `database/schema.sql` e `database/seed.sql` uma vez.

O volume local do Compose não é automaticamente um backup. Em produção, configure backups do MySQL e monitore `GET /api/health`.

## Banco SQLite

A versão escolar usa SQLite local, sem MySQL externo. Ao iniciar a API, o arquivo `database/casa-aurora.db` é criado automaticamente. As tabelas e os 150 produtos são inicializados a partir de `public/menu-data.js`. O schema equivalente está em `database/schema.sqlite.sql`.

```bash
npm install
npm start
```

Teste a conexão:

```bash
curl http://localhost:3000/api/health
```

A resposta indica `database: sqlite` e a quantidade de produtos. Para testar um pedido, use a interface ou envie um `POST /api/orders`. O número real do pedido é gravado nas tabelas `orders` e `order_items`.

No Docker Compose, o volume `sqlite_data` preserva `casa-aurora.db` entre reinícios. No Render sem disco persistente, o SQLite é adequado para demonstração escolar, mas o arquivo pode ser recriado em um redeploy.
